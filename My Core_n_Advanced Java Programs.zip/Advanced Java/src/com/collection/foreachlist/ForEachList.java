package com.collection.foreachlist;

import java.util.ArrayList;
import java.util.List;

public class ForEachList {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		List<String> subList= new ArrayList<String>();
		subList.add("Maths");
		subList.add("Science");
		subList.add("Social");
		subList.add("Kannada");
		subList.add("Sanskrit");
		subList.add("English");
		
		System.out.println("------------Subject Line---------------");
		subList.forEach(sub -> System.out.println(sub));

	}

}
