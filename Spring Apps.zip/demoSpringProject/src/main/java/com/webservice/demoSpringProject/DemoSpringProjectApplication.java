package com.webservice.demoSpringProject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoSpringProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoSpringProjectApplication.class, args);
		
		System.out.println("Welcome to Boot...........");
	}

}
