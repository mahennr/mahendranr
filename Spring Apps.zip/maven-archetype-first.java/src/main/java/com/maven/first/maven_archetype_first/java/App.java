package com.maven.first.maven_archetype_first.java;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World! Mahendra here" );
    }
}
